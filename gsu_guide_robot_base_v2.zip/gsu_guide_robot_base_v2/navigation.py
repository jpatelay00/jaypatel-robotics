import time
from motor_control import MotorController
from sensors import Sensors
from movement import Movement
from camera import RobotCamera
from crosswalk_detector import CrosswalkDetector
from street_crossing import StreetCrossing
from routes import ROUTES

class Navigator:
    def __init__(self):
        self.motors = MotorController()
        self.sensors = Sensors(self.motors)
        self.movement = Movement(self.motors, self.sensors)
        self.camera = RobotCamera()
        self.detector = CrosswalkDetector()
        self.crossing = StreetCrossing(self.camera, self.detector, self.motors)
        self.running = False

    def navigate(self, destination):
        destination = destination.lower().strip()
        route = ROUTES.get(destination)

        if not route:
            print("Unknown destination")
            return False

        if route["status"] != "READY":
            print("*** WORK IN PROGRESS ***")
            print("Destination:", destination)
            print("Start:", route["start"])
            return False

        self.running = True
        print("Navigating to", destination)

        for command, value in route["steps"]:
            if not self.running: break

            if command == "forward": self.movement.forward(value)
            elif command == "backward": self.movement.backward(value)
            elif command == "left": self.movement.left(value)
            elif command == "right": self.movement.right(value)
            elif command == "wait": time.sleep(float(value))
            elif command == "checkpoint": self.camera.save_photo(str(value))
            elif command == "crossing":
                self.movement.stop()
                if self.crossing.request_crossing():
                    self.movement.forward(value)
                else:
                    print("Crossing not approved")
                    self.running = False
            else:
                print("Unknown command:", command)
                self.running = False

        self.stop()
        return True

    def stop(self):
        self.running = False
        self.movement.stop()

    def close(self):
        self.stop()
        self.camera.close()
