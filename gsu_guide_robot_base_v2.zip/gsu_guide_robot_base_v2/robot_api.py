"""Interface intended for the separate phone/web app."""
from navigation import Navigator
from routes import ROUTES

class RobotAPI:
    def __init__(self):
        self.navigator = Navigator()

    def destinations(self):
        return [x for x in ROUTES if not x.startswith("_")]

    def go_to(self, destination):
        return self.navigator.navigate(destination)

    def stop(self):
        self.navigator.stop()

    def status(self):
        return {
            "running": self.navigator.running,
            "distance_cm": self.navigator.sensors.distance_cm(),
            "fake_motors": self.navigator.motors.fake
        }
