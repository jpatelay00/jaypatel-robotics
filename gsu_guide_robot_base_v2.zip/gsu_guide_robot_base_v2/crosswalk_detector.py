from enum import Enum
from config import CROSSWALK_CONFIDENCE

class CrosswalkSignal(Enum):
    WALK = "walk"
    DONT_WALK = "dont_walk"
    UNKNOWN = "unknown"

class CrosswalkDetector:
    """
    Interface for the future camera model.

    WORK IN PROGRESS:
    Train/test a model on the pedestrian signals at the actual intersections.

    Safe default: UNKNOWN. This placeholder never invents a WALK signal.
    """
    def __init__(self):
        self.minimum_confidence = CROSSWALK_CONFIDENCE
        self.model = None

    def load_model(self, model_path):
        # WORK IN PROGRESS
        pass

    def detect(self, frame):
        if frame is None:
            return CrosswalkSignal.UNKNOWN, 0.0

        # WORK IN PROGRESS:
        # run classifier/object detector here
        return CrosswalkSignal.UNKNOWN, 0.0

    def safe_to_cross(self, frame):
        signal, confidence = self.detect(frame)
        return signal == CrosswalkSignal.WALK and confidence >= self.minimum_confidence
